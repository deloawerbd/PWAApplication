if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(reg => console.log('service worker registered', reg))
        .catch(err => console.log('service worker not registered', err));
}
// Head and Menu template
Vue.component('headpart', {
    template: `<div><nav class="z-depth-0">
                <div class= "nav-wrapper container" >
                    <a href="/">Product<span>App</span></a>
                    <span class="right grey-text text-darken-1">
                        <i class="material-icons sidenav-trigger" data-target="side-menu">menu</i>
                    </span>
                </div>
            </nav >
            <ul id="side-menu" class="sidenav side-menu">
                <li><a class="subheader">{{title}}</a></li>
                <li><a href="/" class="waves-effect">{{menu_1}}</a></li>
                <li><a href="/pages/about.html" class="waves-effect">{{menu_2}}</a></li>
                <li><div class="divider"></div></li>
                <li>
                    <a href="/pages/contact.html" class="waves-effect">
                        <i class="material-icons">mail_outline</i>Contact
                     </a>
                </li>

            </ul></div>`,
    data: function () {
        return {
            title: "PRODUCTAPP",
            menu_1: 'Home',
            menu_2: 'About'
        }
    }

});

// Body template
Vue.component('bodypart', {
    template: `<div class="recipes product-container container grey-text text-darken-1">
                <div class="container-head">
                    <a class="btn-small right btn-large add-btn sidenav-trigger" data-target="side-form">
                        <i class="material-icons">add</i> {{activity_1}}
                    </a>
                </div>
                <h6 class="center">{{body_title}}</h6>
                <hr />

            </div>`,
    data: function () {
        return {
            activity_1: "Add Product",
            body_title: 'Products'
        }
    },
    methods: {
        deleteProduct: function (evt) {
            console.log();
        }
    }

});

// Add Products template 
Vue.component('addproductform', {
    props: ['url', 'text'],
    template: `<div id="side-form" class="sidenav side-form">
                <form class="add-recipe container section add-product-form" >
                    <h6>{{add_form_title}}</h6>
                    <div class="divider"></div>
                    <span v-bind:class="{center:true,  error:error,success:success} ">{{message}}</span>
                    <div class="input-field">
                        <input v-bind:placeholder="name_placeholder" v-on:click="defaultMethod" v-model="name"  id="name" type="text" class="validate">
                        <label for="title">{{name_label}}</label>
                    </div>
                    <div class="input-field">
                        <input v-bind:placeholder="qty_placeholder" v-on:click="defaultMethod" v-model="number"  id="number" type="text" class="validate">
                        <label for="ingredients">{{qty_label}}</label>
                    </div>
                    <div class="input-field center">
                        <button class="btn-small submit_button" v-on:click="addProduct">{{action_name}}</button>
                    </div>
                </form>
            </div>`,
    data: function () {
        return {
            add_form_title: "New Product",
            name_placeholder: 'Product name',
            name_label: 'Product Name',
            qty_placeholder: 'Product Quantity',
            qty_label: 'Number of product',
            action_name: 'Add',
            center:true,
            name: "",
            number: "",
            message: "",
            error: false,
            success:true,
        }
    },
    methods: {
        addProduct: function (evt) {
            evt.preventDefault();     

            if (this.name === '' || this.number ==='') {
                this.error = true;
                this.success = false;
                this.message = 'Name and quantity required.';  
            } else {
                // Get current date and time with readable formate
                var today = new Date();
                var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                var dateTime = date + ' ' + time;

                const product = {
                    name: this.name,
                    number: this.number,
                    due_date: dateTime,
                    status: true
                };

                // Adding data into database
                db.collection('products').add(product)
                    .catch(err => {
                        this.error = true;
                        this.success = false;
                        this.message = 'Product added fail';
                    });

                this.name = '';
                this.number = '';
                this.error = false;
                this.success = true;
                this.message = 'Product succcessfully added';   
            }

            
        }, 
        defaultMethod: function (evt) {
            this.error = false;
            this.success = true;
            this.message = '';   
        }
    }

});

// Uodate product template

const updateForm2 = document.querySelector('.update-product-form');

Vue.component('updateproductform', {
    template: `  <div id="side-form-update" class="sidenav side-form-update" style="display:block">
                <form class="add-recipe container section update-product-form" >
                    <h6>{{update_form_title}}</h6>
                    <div class="divider"></div>
                    <span v-bind:class="{center:true,  error:error,success:success, update_product_form_message:true} ">{{message}}</span>
                    <input id="productid"  type="hidden" value="">
                    <div class="input-field">
                        <input v-bind:placeholder="name_placeholder"  id="name" type="text" class="validate">
                        <label for="title">{{name_label}}</label>
                    </div>
                    <div class="input-field">
                        <input v-bind:placeholder="qty_placeholder"  id="number" type="text" class="validate">
                        <label for="ingredients">{{qty_label}}</label>
                    </div>
                    <div class="input-field center">
                        <button class="btn-small submit_button" >{{action_name}}</button>
                    </div>
                </form>
            </div>`,
    data: function () {
        return {
            update_form_title: "Update Product",
            name_placeholder: 'Product name',
            name_label: 'Product Name',
            qty_placeholder: 'Product Quantity',
            qty_label: 'Number of product',
            action_name: 'Update',
            center: true,
            name: "",
            number: "",
            message: "",
            error: false,
            success: true,
            productid:""
        }
    }

});


new Vue({
    el: '#product-app',
	data: {
		appName: 'MyAppVue',
	}
});

const products = document.querySelector('.product-container');

document.addEventListener('DOMContentLoaded', function () {
    // nav menu
    const menus = document.querySelectorAll('.side-menu');
    M.Sidenav.init(menus, { edge: 'right' });
    // add product form
    const forms = document.querySelectorAll('.side-form');
    M.Sidenav.init(forms, { edge: 'left' });
    // Update
    const updateForms = document.querySelectorAll('.side-form-update');
    M.Sidenav.init(updateForms, { edge: 'left' });

});

// render products data
const renderProducts = (data, id) => {
    const html = `
    <div class="card-panel recipe product white row" data-id="${id}">
      <img src="/img/product-48.png" alt="recipe thumb">
      <div class="recipe-details">
        <div class="recipe-title" id="${id}_name">${data.name}</div>
        <div class="recipe-ingredients">Number of products <span class="item_quantity" id="${id}_number">${data.number}</span></div>
        <div class="recipe-ingredients">${data.due_date}</div>
      </div>
       <div class="recipe-delete">

        <a href="#"class="btn-floating btn-small btn-large add-btn sidenav-trigger" >
                <i class="material-icons" data-id="${id}" >delete_outline</i>
        </a>&nbsp;
       <a class="btn-floating btn-small btn-large add-btn sidenav-trigger" data-target="side-form-update">
                <i class="material-icons" data-id="${id}" >create</i>
       </a>
      </div>

    </div>
  `;
    products.innerHTML += html;  

};

const removeProducts = (id) => {
    const product = document.querySelector(`.product[data-id=${id}]`);
    product.remove();
}

const renderUpdatedProducts = (data, id) => {
    document.querySelector('#' + id + '_name').innerText = data.name;
    document.querySelector('#' + id + '_number').innerText = data.number;

};
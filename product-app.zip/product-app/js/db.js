// enable offline data
db.enablePersistence()
    .catch(function (err) {
        if (err.code == 'failed-precondition') {
            // probably multible tabs open at once
            console.log('persistance failed');
        } else if (err.code == 'unimplemented') {
            // lack of browser support for the feature
            console.log('persistance not available');
        }
    });


// real-time listener
db.collection('products').onSnapshot(snapshot => {
    snapshot.docChanges().forEach(change => {
        console.log(change.type, change.doc.id, change.doc.data());
        if (change.type === 'added') {
            // add the document data to the web page
            renderProducts(change.doc.data(), change.doc.id);
        }
        if (change.type === 'removed') {
            // remove the document data from the web page
            removeProducts( change.doc.id);
        }

        if (change.type === 'modified') {
            // update the document data from the web page
            renderUpdatedProducts(change.doc.data(), change.doc.id);
        }
        
    });
});


// Update product
const updateForm = document.querySelector('.update-product-form');
updateForm.addEventListener('submit', evt => {
    evt.preventDefault();
    const id = updateForm.productid.value;
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;

    const product = {
        name: updateForm.name.value,
        number: updateForm.number.value,
        due_date: dateTime,
        status: true
    };

    db.collection('products').doc(id).set(product).catch(err => {
        document.querySelector('.update_product_form_message').style.color = "red";
        document.querySelector('.update_product_form_message').innerText = 'OOPS! update operation fail';
    });

    document.querySelector('.update_product_form_message').style.color = "green";
    document.querySelector('.update_product_form_message').innerText = 'Yea, updated succcessfully';

});



const productContainer = document.querySelector('.product-container');

productContainer.addEventListener('click', evt => {

// Delete products
    if (evt.target.tagName === 'I' && evt.target.textContent === 'delete_outline') {

        var confirmation = confirm("Please confirm to delete item");
        if (confirmation == true) {
            const id = evt.target.getAttribute('data-id');
            db.collection('products').doc(id).delete();
        } 

      
    }

    // insert  products information into update form
        
    if (evt.target.tagName === 'I' && evt.target.textContent === 'create') {
        document.querySelector('.update_product_form_message').innerText = '';
        const id = evt.target.getAttribute('data-id');
        updateForm.name.value = document.querySelector('#' + id + '_name').innerText;
        updateForm.number.value = document.querySelector('#' + id + '_number').innerText;
        updateForm.productid.value = id;
    }

});



